import static pt.ua.concurrent.Console.*;
import pt.ua.concurrent.*;

public class MonitorSharedQueue<T> extends SharedQueue<T>
{
   @SuppressWarnings(value = "unchecked")
   public MonitorSharedQueue()
   {
      queue = (Queue<T>)new Queue();
      mtx = new Mutex();
      emptyCV = mtx.newCV();
      fullCV = mtx.newCV();
      grabCV = mtx.newCV();
      owner = null;
   }

   @SuppressWarnings(value = "unchecked")
   public MonitorSharedQueue(int maxSize)
   {
      assert maxSize >= 0; // sequential precondition!

      queue = (Queue<T>)new Queue(maxSize);
      mtx = new Mutex();
      emptyCV = mtx.newCV();
      fullCV = mtx.newCV();
      grabCV = mtx.newCV();
      owner = null;
   }

   public void in(T elem)
   {
      mtx.lock();
      try
      {
         // sequential precondition:
         assert !isGrabbedByMe() || !queue.isFull();
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         // concurrent precondition:
         if (!isGrabbedByMe())
         {
            while(queue.isFull())
               fullCV.await();
         }
         queue.in(elem);
         emptyCV.broadcast();
      }
      finally
      {
         mtx.unlock();
      }
   }

   public void out()
   {
      mtx.lock();
      try
      {
         // sequential precondition:
         assert !isGrabbedByMe() || !queue.isEmpty();
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         // concurrent precondition:
         if (!isGrabbedByMe())
         {
            while(queue.isEmpty())
               emptyCV.await();
         }
         queue.out();
         fullCV.broadcast();
      }
      finally
      {
         mtx.unlock();
      }
   }

   public T peek()
   {
      T result;

      mtx.lock();
      try
      {
         // sequential precondition:
         assert !isGrabbedByMe() || !queue.isEmpty();
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         // concurrent precondition:
         if (!isGrabbedByMe())
         {
            while(queue.isEmpty())
               emptyCV.await();
         }
         result = queue.peek();
      }
      finally
      {
         mtx.unlock();
      }

      return result;
   }

   public T peekOut()
   {
      T result;

      mtx.lock();
      try
      {
         // sequential precondition:
         assert !isGrabbedByMe() || !queue.isEmpty();
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         // concurrent precondition:
         if (!isGrabbedByMe())
         {
            while(queue.isEmpty())
               emptyCV.await();
         }
         result = queue.peek();
         queue.out();
         fullCV.broadcast();
      }
      finally
      {
         mtx.unlock();
      }

      return result;
   }

   public boolean isEmpty()
   {
      boolean result;

      mtx.lock();
      try
      {
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         result = queue.isEmpty();
      }
      finally
      {
         mtx.unlock();
      }

      return result;
   }

   public boolean isFull()
   {
      boolean result;

      mtx.lock();
      try
      {
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         result = queue.isFull();
      }
      finally
      {
         mtx.unlock();
      }

      return result;
   }

   public int size()
   {
      int result;

      mtx.lock();
      try
      {
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         result = queue.size();
      }
      finally
      {
         mtx.unlock();
      }

      return result;
   }

   public boolean slowValueSeeker(T elem, String id, int colornum)
   {
      assert elem != null;

      boolean result;

      mtx.lock();
      try
      {
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         result = false;
         for(int i = 0; !result && i < queue.size(); i++)
         {
            CThread.pause((int)(Math.random()*10)); // max: 10ms
            result = elem.equals(queue.itemAt(i));
            println(colors[colornum], "["+id+"]: search value "+elem+" in index "+i);
         }
      }
      finally
      {
         mtx.unlock();
      }

      return result;
   }

   public void grab()
   {
      mtx.lock();
      try
      {
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         owner = Thread.currentThread();
      }
      finally
      {
         mtx.unlock();
      }
   }

   public void release()
   {
      assert isGrabbedByMe();

      mtx.lock();
      try
      {
         owner = null;
         grabCV.broadcast();
      }
      finally
      {
         mtx.unlock();
      }
   }

   public boolean isGrabbedByMe()
   {
      return (owner != null) && (owner.getId() == Thread.currentThread().getId());
   }

   protected final Queue<T> queue;
   protected final Mutex mtx;
   protected final MutexCV emptyCV;
   protected final MutexCV fullCV;
   // external synchronization:
   protected final MutexCV grabCV;
   protected volatile Thread owner;
}

