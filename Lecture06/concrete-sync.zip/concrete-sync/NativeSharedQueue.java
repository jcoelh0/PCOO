import static pt.ua.concurrent.Console.*;
import pt.ua.concurrent.*;

public class NativeSharedQueue<T> extends SharedQueue<T>
{
   @SuppressWarnings(value = "unchecked")
   public NativeSharedQueue()
   {
      queue = (Queue<T>)new Queue();
      owner = null;
   }

   @SuppressWarnings(value = "unchecked")
   public NativeSharedQueue(int maxSize)
   {
      assert maxSize >= 0; // sequential precondition!

      queue = (Queue<T>)new Queue(maxSize);
      owner = null;
   }

   public synchronized void in(T elem)
   {
      // sequential precondition:
      assert !isGrabbedByMe() || !queue.isFull();
      // external synchronization:
      while(owner != null && !isGrabbedByMe())
         await();
      // concurrent precondition:
      if (!isGrabbedByMe())
      {
         while(queue.isFull())
            await();
      }
      queue.in(elem);
      notifyAll();
   }

   public synchronized void out()
   {
      // sequential precondition:
      assert !isGrabbedByMe() || !queue.isEmpty();
      // external synchronization:
      while(owner != null && !isGrabbedByMe())
         await();
      // concurrent precondition:
      if (!isGrabbedByMe())
      {
         while(queue.isEmpty())
            await();
      }
      queue.out();
      notifyAll();
   }

   public synchronized T peek()
   {
      T result;

      // sequential precondition:
      assert !isGrabbedByMe() || !queue.isEmpty();
      // external synchronization:
      while(owner != null && !isGrabbedByMe())
         await();
      // concurrent precondition:
      if (!isGrabbedByMe())
      {
         while(queue.isEmpty())
            await();
      }
      result = queue.peek();

      return result;
   }

   public synchronized T peekOut()
   {
      T result;

      // sequential precondition:
      assert !isGrabbedByMe() || !queue.isEmpty();
      // external synchronization:
      while(owner != null && !isGrabbedByMe())
         await();
      // concurrent precondition:
      if (!isGrabbedByMe())
      {
         while(queue.isEmpty())
            await();
      }
      result = queue.peek();
      queue.out();
      notifyAll();

      return result;
   }

   public synchronized boolean isEmpty()
   {
      boolean result;

      // external synchronization:
      while(owner != null && !isGrabbedByMe())
         await();
      result = queue.isEmpty();

      return result;
   }

   public synchronized boolean isFull()
   {
      boolean result;

      // external synchronization:
      while(owner != null && !isGrabbedByMe())
         await();
      result = queue.isFull();

      return result;
   }

   public synchronized int size()
   {
      int result;

      // external synchronization:
      while(owner != null && !isGrabbedByMe())
         await();
      result = queue.size();

      return result;
   }

   public synchronized boolean slowValueSeeker(T elem, String id, int colornum)
   {
      assert elem != null;

      boolean result;

      // external synchronization:
      while(owner != null && !isGrabbedByMe())
         await();
      result = false;
      for(int i = 0; !result && i < queue.size(); i++)
      {
         CThread.pause((int)(Math.random()*10)); // max: 10ms
         result = elem.equals(queue.itemAt(i));
         println(colors[colornum], "["+id+"]: search value "+elem+" in index "+i);
      }

      return result;
   }

   public synchronized void grab()
   {
      while(owner != null && !isGrabbedByMe())
         await();
      owner = Thread.currentThread();
   }

   public synchronized void release()
   {
      assert isGrabbedByMe();

      owner = null;
      notifyAll();
   }

   public synchronized boolean isGrabbedByMe()
   {
      return (owner != null) && (owner.getId() == Thread.currentThread().getId());
   }

   protected void await()
   {
      try
      {
         wait();
      }
      catch(InterruptedException e)
      {
         throw new ThreadInterruptedException(e);
      }

   }

   protected final Queue<T> queue;
   // external synchronization:
   protected volatile Thread owner;
}

