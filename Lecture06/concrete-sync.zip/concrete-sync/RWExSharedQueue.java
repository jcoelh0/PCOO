import static pt.ua.concurrent.Console.*;
import pt.ua.concurrent.*;

public class RWExSharedQueue<T> extends SharedQueue<T>
{
   @SuppressWarnings(value = "unchecked")
   public RWExSharedQueue()
   {
      queue = (Queue<T>)new Queue();
      rwex = new RWEx();
      emptyCV = rwex.newCV();
      fullCV = rwex.newCV();
      grabCV = rwex.newCV();
      owner = null;
   }

   @SuppressWarnings(value = "unchecked")
   public RWExSharedQueue(int maxSize)
   {
      assert maxSize >= 0; // sequential precondition!

      queue = (Queue<T>)new Queue(maxSize);
      rwex = new RWEx();
      emptyCV = rwex.newCV();
      fullCV = rwex.newCV();
      grabCV = rwex.newCV();
      owner = null;
   }

   public void in(T elem)
   {
      rwex.lockWriter();
      try
      {
         // sequential precondition:
         assert !isGrabbedByMe() || !queue.isFull();
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         // concurrent precondition:
         if (!isGrabbedByMe())
         {
            while(queue.isFull())
               fullCV.await();
         }
         queue.in(elem);
         emptyCV.broadcast();
      }
      finally
      {
         rwex.unlockWriter();
      }
   }

   public void out()
   {
      rwex.lockWriter();
      try
      {
         // sequential precondition:
         assert !isGrabbedByMe() || !queue.isEmpty();
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         // concurrent precondition:
         if (!isGrabbedByMe())
         {
            while(queue.isEmpty())
               emptyCV.await();
         }
         queue.out();
         fullCV.broadcast();
      }
      finally
      {
         rwex.unlockWriter();
      }
   }

   public T peek()
   {
      T result;

      rwex.lockReader();
      try
      {
         // sequential precondition:
         assert !isGrabbedByMe() || !queue.isEmpty();
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         // concurrent precondition:
         if (!isGrabbedByMe())
         {
            while(queue.isEmpty())
               emptyCV.await();
         }
         result = queue.peek();
      }
      finally
      {
         rwex.unlockReader();
      }

      return result;
   }

   public T peekOut()
   {
      T result;

      rwex.lockWriter();
      try
      {
         // sequential precondition:
         assert !isGrabbedByMe() || !queue.isEmpty();
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         // concurrent precondition:
         if (!isGrabbedByMe())
         {
            while(queue.isEmpty())
               emptyCV.await();
         }
         result = queue.peek();
         queue.out();
         fullCV.broadcast();
      }
      finally
      {
         rwex.unlockWriter();
      }

      return result;
   }

   public boolean isEmpty()
   {
      boolean result;

      rwex.lockReader();
      try
      {
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         result = queue.isEmpty();
      }
      finally
      {
         rwex.unlockReader();
      }

      return result;
   }

   public boolean isFull()
   {
      boolean result;

      rwex.lockReader();
      try
      {
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         result = queue.isFull();
      }
      finally
      {
         rwex.unlockReader();
      }

      return result;
   }

   public int size()
   {
      int result;

      rwex.lockReader();
      try
      {
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         result = queue.size();
      }
      finally
      {
         rwex.unlockReader();
      }

      return result;
   }

   public boolean slowValueSeeker(T elem, String id, int colornum)
   {
      assert elem != null;

      boolean result;

      rwex.lockReader();
      try
      {
         // external synchronization:
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         result = false;
         for(int i = 0; !result && i < queue.size(); i++)
         {
            CThread.pause((int)(Math.random()*10)); // max: 10ms
            result = elem.equals(queue.itemAt(i));
            println(colors[colornum], "["+id+"]: search value "+elem+" in index "+i);
         }
      }
      finally
      {
         rwex.unlockReader();
      }

      return result;
   }

   public void grab()
   {
      rwex.lockWriter();
      try
      {
         while(owner != null && !isGrabbedByMe())
            grabCV.await();
         owner = Thread.currentThread();
      }
      finally
      {
         rwex.unlockWriter();
      }
   }

   public void release()
   {
      assert isGrabbedByMe();

      rwex.lockWriter();
      try
      {
         owner = null;
         grabCV.broadcast();
      }
      finally
      {
         rwex.unlockWriter();
      }
   }

   public boolean isGrabbedByMe()
   {
      return (owner != null) && (owner.getId() == Thread.currentThread().getId());
   }

   protected final Queue<T> queue;
   protected final RWEx rwex;
   protected final RWExCV emptyCV;
   protected final RWExCV fullCV;
   // external synchronization:
   protected final RWExCV grabCV;
   protected volatile Thread owner;
}

