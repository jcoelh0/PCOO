/**
 * Generic queue module.
 *
 * <P>This class follows Design by Contract(tm) methodology.
 *
 * @author Miguel Oliveira e Silva (mos@ua.pt)
 */
public class Queue<T>
{
   /**
    * Creates an unlimited empty queue.
    * <P>
    * <DL><DT><B>Postcondition:</B></DT>
    *   <DD>{@code isEmpty()} - empty queue.</DD>
    * </DL>
    */
   public Queue()
   {
      this.maxSize = -1;

      assert isEmpty();
   }

   /**
    * Creates a limited empty queue.
    * <P>
    * <DL><DT><B>Precondition:</B></DT>
    *   <DD>{@code maxSize >= 0}</DD>
    * </DL>
    * <DL><DT><B>Postcondition:</B></DT>
    *   <DD>{@code isEmpty()} - empty queue.</DD>
    * </DL>
    */
   public Queue(int maxSize)
   {
      assert maxSize >= 0;

      this.maxSize = maxSize;

      assert isEmpty();
   }

   /**
    * Adds an element to the end of the queue.
    * <P>
    * <DL><DT><B>Precondition:</B></DT>
    *   <DD>{@code !isFull()} - non full queue</DD>
    * </DL>
    * <DL><DT><B>Postcondition:</B></DT>
    *   <DD>{@code !isEmpty()} - non empty queue</DD>
    * </DL>
    *
    * @param elem the element to queue.
    */
   public void in(T elem)
   {
      assert !isFull(): "full queue!";

      Node<T> n = new Node<T>();
      n.elem = elem;
      n.next = null;

      if (isEmpty())
         first = n;
      else
         last.next = n;

      last = n;
      size++;

      assert !isEmpty();
   }

   /**
    * Removes the first element of the queue.
    * <P>
    * <DL><DT><B>Precondition:</B></DT>
    *   <DD>{@code !isEmpty()} - non empty queue</DD>
    * </DL>
    */
   public void out()
   {
      assert !isEmpty(): "empty queue!";

      size--;
      first = first.next;
   }

   /**
    * Without changing the queue, returns its first element.
    * <P>
    * <DL><DT><B>Precondition:</B></DT>
    *   <DD>{@code !isEmpty()} - non empty queue</DD>
    * </DL>
    * 
    * @return the first element of the queue.
    */
   public T peek()
   {
      assert !isEmpty(): "empty queue!";

      return first.elem;
   }

   /**
    * Checks if the queue is empty.
    * 
    * @return  {@code true} if empty, otherwise it returns {@code false}.
    */
   public boolean isEmpty()
   {
      return size() == 0;
   }

   /**
    * Is the queue limited?
    * 
    * @return  {@code true} if limited, otherwise it returns {@code false}.
    */
   public boolean isLimited()
   {
      return maxSize >= 0;
   }

   /**
    * Checks if the queue is full.
    * 
    * @return  {@code true} if full, otherwise it returns {@code false}.
    */
   public boolean isFull()
   {
      return size() == maxSize;
   }

   /**
    * Returns the number of elements in the queue.
    *
    * @return  number of elements.
    */
   public int size()
   {
      return size;
   }

   /**
    * Returns the maximum number of elements of the queue.
    *
    * @return  maximum number of elements.
    */
   public int maxSize()
   {
      assert isLimited(): "unlimited queue!";

      return maxSize;
   }

   public T itemAt(int idx)
   {
      assert idx >= 0 && idx < size(): "invalid index: "+idx;

      Node<T> p = first;
      for(int i = 0; i < idx; i++)
         p = p.next;
      return p.elem;
   }
   /**
    * Empties the queue.
    * <P>
    * <DL><DT><B>Postcondition:</B></DT>
    *   <DD>{@code isEmpty()} - empty queue.</DD>
    * </DL>
    */
   public void clear()
   {
      first = last = null;
      size = 0;

      assert isEmpty();
   }

   private Node<T> first = null;
   private Node<T> last = null;
   private int size = 0;
   private final int maxSize;

   private class Node<T>
   {
      T elem;
      Node<T> next;
   }
}

