
public abstract class SharedQueue<T>
{
   public abstract void in(T elem);
   public abstract void out();
   public abstract T peek();
   public abstract T peekOut();
   public abstract boolean isEmpty();
   public abstract boolean isFull();
   public abstract int size();
   public abstract boolean slowValueSeeker(T elem, String id, int colornum);
   public abstract void grab();
   public abstract void release();
   public abstract boolean isGrabbedByMe();
}

